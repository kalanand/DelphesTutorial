/*******************************************************************************
*									       *
* mcf_nTupleBuild.h -- Include file for mcfast generalized nTuple Builder GUI  *
*									       *
*	P. Lebrun, September 1995.					       *
*									       *
*******************************************************************************/
#define APP_NAME "mcfio_Browse" /* application name for loading X resources */
#define APP_CLASS "MCFIO_Browse"

