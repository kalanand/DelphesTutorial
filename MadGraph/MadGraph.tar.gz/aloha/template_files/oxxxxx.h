#ifndef o_guard
#define o_guard
#include <complex>
void oxxxxx(double p[4],double fmass,int nhel,int nsf,std::complex<double> fo[6]);
#endif
